/** @file
  Private USB gadget-controller protocol shared by the UMS512 MUSB backend
  and USB function drivers.
**/
#ifndef SPRD_USB_DEVICE_CONTROLLER_PROTOCOL_H_
#define SPRD_USB_DEVICE_CONTROLLER_PROTOCOL_H_

#include <Uefi.h>

#define SPRD_USB_DEVICE_CONTROLLER_PROTOCOL_GUID \
  { 0x04c2db60, 0x14ae, 0x4ac0, { 0xb2, 0x85, 0x1d, 0x03, 0x77, 0x76, 0x71, 0x7e } }

typedef struct _SPRD_USB_DEVICE_CONTROLLER_PROTOCOL SPRD_USB_DEVICE_CONTROLLER_PROTOCOL;

typedef
VOID
(EFIAPI *SPRD_USB_DEVICE_RESET_CALLBACK)(
  IN VOID  *Context
  );

typedef
VOID
(EFIAPI *SPRD_USB_DEVICE_SETUP_CALLBACK)(
  IN VOID         *Context,
  IN CONST UINT8  Setup[8]
  );

/**
  Called for one complete bulk OUT packet.  Data is valid only for the
  duration of the callback; clients that need it later must copy it.
**/
typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_BULK_OUT_CALLBACK)(
  IN VOID         *Context,
  IN UINT8        EndpointAddress,
  IN CONST UINT8  *Data,
  IN UINTN        Length
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_START)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This,
  IN SPRD_USB_DEVICE_RESET_CALLBACK        ResetCallback,
  IN SPRD_USB_DEVICE_SETUP_CALLBACK        SetupCallback,
  IN VOID                                  *Context
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_STOP)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_EP0_TRANSMIT)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This,
  IN CONST UINT8                           *Data,
  IN UINTN                                 Length,
  IN UINT16                                RequestedLength
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_EP0_STATUS)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_EP0_STALL)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_SET_ADDRESS)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This,
  IN UINT8                                 Address
  );

/**
  Configure one bulk IN and one bulk OUT endpoint for the active device
  function.  UMS512 uses EP5 IN and EP6 OUT for the mass-storage function.
**/
typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_CONFIGURE_BULK_ENDPOINTS)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This,
  IN UINT8                                BulkInEndpointAddress,
  IN UINT8                                BulkOutEndpointAddress,
  IN UINT16                               MaximumPacketSize,
  IN SPRD_USB_DEVICE_BULK_OUT_CALLBACK    BulkOutCallback,
  IN VOID                                 *Context
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_BULK_TRANSMIT)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This,
  IN UINT8                                EndpointAddress,
  IN CONST UINT8                          *Data,
  IN UINTN                                Length,
  IN BOOLEAN                              SendZeroLengthPacket
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_BULK_RESET)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_BULK_STALL)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This,
  IN UINT8                                EndpointAddress
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_DEVICE_RECONNECT)(
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *This
  );

struct _SPRD_USB_DEVICE_CONTROLLER_PROTOCOL {
  UINT64                           Revision;
  SPRD_USB_DEVICE_START            Start;
  SPRD_USB_DEVICE_STOP             Stop;
  SPRD_USB_DEVICE_EP0_TRANSMIT     Ep0Transmit;
  SPRD_USB_DEVICE_EP0_STATUS       Ep0SendStatus;
  SPRD_USB_DEVICE_EP0_STALL        Ep0Stall;
  SPRD_USB_DEVICE_SET_ADDRESS      SetAddress;
  SPRD_USB_DEVICE_CONFIGURE_BULK_ENDPOINTS ConfigureBulkEndpoints;
  SPRD_USB_DEVICE_BULK_TRANSMIT    BulkTransmit;
  SPRD_USB_DEVICE_BULK_RESET       BulkReset;
  SPRD_USB_DEVICE_BULK_STALL       BulkStall;
  SPRD_USB_DEVICE_RECONNECT        Reconnect;
};

#define SPRD_USB_DEVICE_CONTROLLER_PROTOCOL_REVISION  0x00010002

extern EFI_GUID  gSprdUsbDeviceControllerProtocolGuid;

#endif
