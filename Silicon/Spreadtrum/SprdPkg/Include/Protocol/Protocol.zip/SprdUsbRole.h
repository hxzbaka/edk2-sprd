/** @file
  Role ownership protocol for the single UMS512 MUSB OTG controller.
**/
#ifndef SPRD_USB_ROLE_PROTOCOL_H_
#define SPRD_USB_ROLE_PROTOCOL_H_

#include <Uefi.h>

#define SPRD_USB_ROLE_PROTOCOL_GUID \
  { 0x38a84b8d, 0x5834, 0x4de9, { 0xb5, 0x1c, 0x0c, 0x93, 0x88, 0xc0, 0xab, 0x64 } }

typedef enum {
  SprdUsbRoleNone,
  SprdUsbRoleHost,
  SprdUsbRoleDevice
} SPRD_USB_ROLE;

typedef enum {
  SprdUsbRolePolicyAuto,
  SprdUsbRolePolicyHost,
  SprdUsbRolePolicyDevice
} SPRD_USB_ROLE_POLICY;

typedef struct _SPRD_USB_ROLE_PROTOCOL SPRD_USB_ROLE_PROTOCOL;

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_ROLE_GET_ROLE)(
  IN SPRD_USB_ROLE_PROTOCOL  *This,
  OUT SPRD_USB_ROLE          *Role
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_ROLE_SET_POLICY)(
  IN SPRD_USB_ROLE_PROTOCOL  *This,
  IN SPRD_USB_ROLE_POLICY    Policy
  );

struct _SPRD_USB_ROLE_PROTOCOL {
  UINT32                    Revision;
  SPRD_USB_ROLE_GET_ROLE    GetRole;
  SPRD_USB_ROLE_SET_POLICY  SetPolicy;
};

#define SPRD_USB_ROLE_PROTOCOL_REVISION  0x00010000

extern EFI_GUID  gSprdUsbRoleProtocolGuid;

#endif
