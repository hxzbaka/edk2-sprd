/** @file
  UMS512 USB2 platform services shared by the MUSB host and function stacks.
**/
#ifndef SPRD_USB_PLATFORM_PROTOCOL_H_
#define SPRD_USB_PLATFORM_PROTOCOL_H_

#include <Uefi.h>

#define SPRD_USB_PLATFORM_PROTOCOL_GUID \
  { 0x7b0e4264, 0x3990, 0x4b7f, { 0xa2, 0x06, 0x46, 0xbb, 0x7c, 0x89, 0x32, 0x42 } }

typedef struct _SPRD_USB_PLATFORM_PROTOCOL SPRD_USB_PLATFORM_PROTOCOL;

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_PLATFORM_INITIALIZE)(
  IN SPRD_USB_PLATFORM_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_PLATFORM_SET_VBUS)(
  IN SPRD_USB_PLATFORM_PROTOCOL  *This,
  IN BOOLEAN                     Enable
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_PLATFORM_SET_PHY_ROLE)(
  IN SPRD_USB_PLATFORM_PROTOCOL  *This,
  IN BOOLEAN                     Peripheral
  );

struct _SPRD_USB_PLATFORM_PROTOCOL {
  UINT32                        Revision;
  SPRD_USB_PLATFORM_INITIALIZE  Initialize;
  SPRD_USB_PLATFORM_SET_VBUS    SetVbus;
  SPRD_USB_PLATFORM_SET_PHY_ROLE SetPhyRole;
};

#define SPRD_USB_PLATFORM_PROTOCOL_REVISION  0x00010000

extern EFI_GUID  gSprdUsbPlatformProtocolGuid;

#endif
