/** @file
  Private USB Mass Storage function protocol for the sprd gadget stack.
**/
#ifndef SPRD_USB_MSD_PROTOCOL_H_
#define SPRD_USB_MSD_PROTOCOL_H_

#include <Uefi.h>
#include <Protocol/SprdUsbDeviceController.h>

#define SPRD_USB_MSD_PROTOCOL_GUID \
  { 0x69e2ed3d, 0x4ea9, 0x4632, { 0xa4, 0x91, 0x6a, 0xb3, 0x11, 0xc1, 0x4e, 0x83 } }

typedef struct _SPRD_USB_MSD_PROTOCOL SPRD_USB_MSD_PROTOCOL;

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_MSD_ATTACH_CONTROLLER)(
  IN SPRD_USB_MSD_PROTOCOL                *This,
  IN SPRD_USB_DEVICE_CONTROLLER_PROTOCOL  *Controller
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_MSD_START)(
  IN SPRD_USB_MSD_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_MSD_STOP)(
  IN SPRD_USB_MSD_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_MSD_RESET)(
  IN SPRD_USB_MSD_PROTOCOL  *This
  );

typedef
EFI_STATUS
(EFIAPI *SPRD_USB_MSD_BULK_OUT)(
  IN SPRD_USB_MSD_PROTOCOL  *This,
  IN UINT8                  EndpointAddress,
  IN CONST UINT8            *Data,
  IN UINTN                  Length
  );

struct _SPRD_USB_MSD_PROTOCOL {
  UINT64                           Revision;
  SPRD_USB_MSD_ATTACH_CONTROLLER   AttachController;
  SPRD_USB_MSD_START               Start;
  SPRD_USB_MSD_STOP                Stop;
  SPRD_USB_MSD_RESET               Reset;
  SPRD_USB_MSD_BULK_OUT            BulkOut;
};

#define SPRD_USB_MSD_PROTOCOL_REVISION  0x00010000

extern EFI_GUID  gSprdUsbMsdProtocolGuid;

#endif
